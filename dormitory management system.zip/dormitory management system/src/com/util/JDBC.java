/**
 * 
 */
/**
 * @author admin
 *
 */
package com.util;
import java.sql.*;

public class JDBC {
	static String url="jdbc:mysql://localhost:3306/dormitorymanagementsystem?characterEncoding=utf-8&serverTimezone=GMT%2B8";
	static String username="root";
	static String password="yi97875539";
	static Connection conn  =null;
	static Statement s=null;
	static PreparedStatement ps =null;//////////
	static ResultSet rs=null;
	
	public static void init() {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			conn = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			System.out.println("SQL���������ʼ��ʧ��");
			e.printStackTrace();
		}
	}
	
	public static ResultSet selectsql(String sql) {
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("sql���ݿ��ѯ�쳣");
			e.printStackTrace();
		}
		return rs;
	}
	
	public static PreparedStatement createStatement(String sql) {
		try {
			return conn.prepareStatement(sql);
		}
		catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static void close() {
		try {
			//rs.close();
			//ps.close();
			conn.close();
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("���ݿ�ر��쳣");
			e.printStackTrace();
		}
	}
	/*
	 * public static void main(String[] args) throws SQLException{ try { //ע�����ݿ�����
	 * DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
	 * //Class.forName("com.mysql.jdbc.Driver"); //DriverMannager��ȡ���ݿ�����
	 * 
	 * Connection conn=DriverManager.getConnection(url,username,password);
	 * //ͨ��connection��ȡstatement Statement s =conn.createStatement(); //ִ��SQL String
	 * sql="select * from id"; ResultSet rs=s.executeQuery(sql); //
	 * System.out.println("sno |pass |aclass"); while(rs.next()) { //int
	 * id=rs.getInt("id"); String sno=rs.getString("sno"); String
	 * pass=rs.getString("pass"); String
	 * aclass=rs.getString("class");//class�ǹؼ��֣������� // Date
	 * birthday=rs.getDate("birthday"); System.out.println(sno+"|"+pass+"|"+aclass);
	 * } rs.close(); s.close(); conn.close(); } catch (SQLException ce) { // TODO:
	 * handle exception System.out.println(ce); } }
	 */
}