package com.entity;

public class dormitorys {
	
	private String fn;//¥��
	private String drom;//�����
	private String rt;//�ۻ�������
	private String unrt;//�ۻ���������
	private String sex;//�Ա�
	/////////////////////////////////////////////////
	public String getFn() {
		return fn;
	}
	public void setFn(String fn) {
		this.fn = fn;
	}
	/////////////////////////////////////////////////
	public String getDrom() {
		return drom;
	}
	public void setDrom(String drom) {
		this.drom = drom;
	}
	/////////////////////////////////////////////////
	public String getRt() {
		return rt;
	}
	public void setRt(String rt) {
		this.rt = rt;
	}
	/////////////////////////////////////////////////
	public void setUnrt(String unrt) {
		this.unrt = unrt;
	}
	public String getUnrt()
	{
		return unrt;
	}
	/////////////////////////////////////////////////
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
}
