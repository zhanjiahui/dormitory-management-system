package com.dao;

import java.sql.*;

import java.util.List;

import org.apache.tomcat.util.buf.UDecoder;

import java.util.ArrayList;

import com.util.JDBC;
import com.entity.*;

public class userDaoimpl {
	public boolean login(String id, String password) {
		boolean flag = false;
		try {
			JDBC.init();
			ResultSet rs = JDBC
					.selectsql("select sno,pass from id where sno =\"" + id + "\" and pass = \"" + password + "\"");
			while (rs.next()) {
				if (rs.getString("sno").equals(id) && rs.getString("pass").equals(password)) {
					flag = true;
					// System.out.println("��½�ɹ�");
				}
			}
			JDBC.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	//rs.getString("class").equals("���Ա")
	public boolean aclass(String id) {
		boolean flag = false;
		try {
			JDBC.init();
			ResultSet rs = JDBC
					.selectsql("select sno,class from id where sno =\"" + id + "\"");
			String s="���Ա";
			while (rs.next()) {
				if (s.equals(rs.getString("class"))) {
					flag = true;
				}
			}
			JDBC.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	/*
	 * public boolean onDutyTime(String id) { 
	 * boolean flag=false; 
	 * try { JDBC.init();
	 * //System.out.println("select sno,pass from id where sno = "
	 *  //+id+"and pass = "+password);
	 *  ResultSet rs=JDBC.selectsql("select week,day from si where sno =\"" +id+"\"");
	 * 
	 * while(rs.next()) { 
	 * if(rs.getString("sno").equals(id)) {
	 *  String week=rs.getInt("week")+""; 
	 *  String day=rs.getInt("day")+"";
	 *   flag=true;
	 * //System.out.println("��½�ɹ�"); } }
	 * JDBC.close(); }catch(SQLException e) { e.printStackTrace(); } 
	 * return flag; }
	 */
	 
	public List<users> onDutyTime(String id) {
		List<users> list = new ArrayList<users>();
		try {
			JDBC.init();
			ResultSet rs = JDBC.selectsql("select sno,week,day from si where sno =\"" + id + "\"");
			System.out.println("select sno,week,day from si where sno =\"" + id + "\"");
			while (rs.next()) {
				System.out.println(rs.getString("sno"));
				//if (rs.getString("sno").equals(id)) {
					System.out.println("m");
					users user = new users();
					user.setWeek(rs.getString("week"));
					user.setDay(rs.getString("day"));
					list.add(user);
				//}
			}
			JDBC.close();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<dormitorys> thisterm(String id) {
		List<dormitorys> list = new ArrayList<dormitorys>();
		try {
			JDBC.init();
			ResultSet rs = JDBC.selectsql("select * from r");
			System.out.println("select * from r");
			while (rs.next()) {
			//	System.out.println(rs.getString("sno"));
				//if (rs.getString("sno").equals(id)) {
				//	System.out.println("m");
					dormitorys dormitory = new dormitorys();
					dormitory.setFn(rs.getString("fn"));
					dormitory.setDrom(rs.getString("drom"));
					dormitory.setRt(rs.getString("rt"));
					dormitory.setUnrt(rs.getString("unrt"));
					dormitory.setSex(rs.getString("sex"));					
					list.add(dormitory);
				//}
			}
			JDBC.close();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void insertDormitory(dormitorys dormitory) {
		JDBC.init();
		
		String sql = "INSERT INTO r(fn, drom, rt, unrt, sex) VALUES(?, ?, ?, ?, ?)";
		PreparedStatement statement = JDBC.createStatement(sql);
		
		try {
			statement.setString(1, dormitory.getFn());
			statement.setString(2, dormitory.getDrom());
			statement.setString(3, dormitory.getRt());
			statement.setString(4, dormitory.getUnrt());
			statement.setString(5, dormitory.getSex());
			
			statement.executeUpdate();
		}catch (SQLException ex) {
			ex.printStackTrace();
		}

		JDBC.close();
	}

	/*
	 * public List<dormitorys> entry(String id) { List<dormitorys> list = new
	 * ArrayList<dormitorys>(); try {
	 * 
	 * JDBC.init(); //JDBC.selectsql(sql).ps.
	 * executeUpdate("insert into r(fn,drom,rt,unrt,sex) values(?,?,?,?,?)");
	 * ResultSet rs =
	 * JDBC.selectsql("insert into r(fn,drom,rt,unrt,sex) values(?,?,?,?,?)");
	 * //System.out.println("select * from r");\ //INSERT INTO
	 * wenxian(ChineseName,EnglishName,Type,Author,Source,ChineseAbstract,
	 * EnglishAbstract,ChineseKeyword,EnglishKeyword,ReforName,Incentive,Content)
	 * VALUES (?,?,?,?,?,?,?,?,?,?,?,?) while (rs.next()) {
	 * 
	 * dormitorys dormitory = new dormitorys();
	 * 
	 * rs.updateString(1,dormitory.getFn()); rs.updateString(2,dormitory.getDrom());
	 * rs.updateString(3,dormitory.getRt()); rs.updateString(4,dormitory.getUnrt());
	 * rs.updateString(5,dormitory.getSex()); rs.executeUpdate(); } JDBC.close();
	 * return list; } catch (SQLException e) { e.printStackTrace(); } return null; }
	 */
//�������һ��������Ų�Ҫɾ����~
}


