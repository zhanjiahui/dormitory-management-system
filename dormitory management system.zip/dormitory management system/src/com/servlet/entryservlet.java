package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.userDaoimpl;
import com.entity.dormitorys;
import com.entity.users;

import java.sql.*;
/**
 * Servlet implementation class entryservlet
 */
@WebServlet("/entryservlet")
public class entryservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public entryservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//������д�����ݿ���
        
		String week=request.getParameter("week");
		String day=request.getParameter("day");
		String fn=request.getParameter("fn");
		String drom=request.getParameter("drom");
	//	String rt=request.getParameter("rt");
	//	String unrt=request.getParameter("unrt");
		String sex=request.getParameter("sex");
		sex = new String(sex.getBytes("iso-8859-1"), "utf-8");
		System.out.println(sex);
//***********���������***************************
		String rt;
		String unrt;
		int flagrt=0;
		int flagunrt=0;
		if("��".equals(request.getParameter("rt"))) {
			flagrt++;
		}else {
			flagunrt++;
		}
		rt=String.valueOf(flagrt);
		unrt=String.valueOf(flagunrt);
//**************************************************
		dormitorys dormitory = new dormitorys();
		//dormintory.setWeek(week);
		//dormintory.setDay(day);
		dormitory.setFn(fn);
		dormitory.setDrom(drom);
		dormitory.setRt(rt);
		dormitory.setUnrt(unrt);
		dormitory.setSex(sex);

            userDaoimpl ud = new userDaoimpl(); 
            ud.insertDormitory(dormitory);
	        request.setAttribute("fn", dormitory.getFn()); //��request���з�����Ϣ 
	        request.setAttribute("drom", dormitory.getDrom());
	        request.setAttribute("rt", dormitory.getRt());
	        request.setAttribute("unrt", dormitory.getUnrt());
	        request.setAttribute("sex", dormitory.getSex());
	        userDaoimpl ud1=new userDaoimpl();
	      //  statement.executeUpdate();

	        request.getRequestDispatcher("success.jsp").forward(request, response);
	        
	        //response.sendRedirect("success.jsp");
		doGet(request, response);
	}

}
