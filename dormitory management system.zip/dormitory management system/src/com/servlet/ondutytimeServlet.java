package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.userDaoimpl;
import com.entity.users;

/**
 * Servlet implementation class ondutytimeServlet
 */
@WebServlet("/ondutytimeServlet")
public class ondutytimeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ondutytimeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		String week=request.getParameter("week");
		String day=request.getParameter("day");
		String aclass=request.getParameter("aclass");
			users user = new users();
            user.setId(id);
            user.setAClass(aclass);
            user.setWeek(week);
            user.setDay(day);
            userDaoimpl ud = new userDaoimpl(); 
      //      if(ud.onDutyTime(id)){  
	        request.setAttribute("week", user.getWeek()); //��request���з�����Ϣ 
	        request.setAttribute("day", user.getDay());
	        request.setAttribute("aclass", user.getAClass());
	    //    request.getRequestDispatcher("onDutyTime.jsp").forward(request, response);//ת�����ɹ�ҳ�� 
	   // }else{
	  //      response.sendRedirect("relogin.jsp");//�ض�����ҳ 
	  //  }  
		doGet(request, response);
	}

}
