package com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.dao.userDaoimpl;
import com.entity.dormitorys;
import com.entity.users;
import com.servlet.loginservlet;

/**
 * Servlet Filter implementation class dormitorysFilter
 */
@WebFilter("/dormitorysFilter")
public class dormitorysFilter implements Filter {

    /**
     * Default constructor. 
     */
    public dormitorysFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest req = (HttpServletRequest) request;
		
		String userId = (String)req.getSession().getAttribute(loginservlet.SESSION_USER_ID);
            
            userDaoimpl ud = new userDaoimpl(); 
           // users user = ud.onDutyTime(userId).get(0);
            dormitorys dormitory = ud.thisterm(userId).get(0);
	        request.setAttribute("fn", dormitory.getFn()); //��request���з�����Ϣ 
	        request.setAttribute("drom", dormitory.getDrom());
	        request.setAttribute("rt", dormitory.getRt());
	        request.setAttribute("unrt", dormitory.getUnrt());
	        request.setAttribute("sex", dormitory.getSex());
	        
	        System.out.println("������������һ��");
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
