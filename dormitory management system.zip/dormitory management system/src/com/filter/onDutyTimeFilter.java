package com.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.dao.userDaoimpl;
import com.entity.users;
import com.servlet.loginservlet;

/**
 * Servlet Filter implementation class onDutyTime
 */
@WebFilter("/onDutyTime")
public class onDutyTimeFilter implements Filter {

    /**
     * Default constructor. 
     */
    public onDutyTimeFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("----����������----");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		/*
		String id=request.getParameter("id");
		String week=request.getParameter("week");
		String day=request.getParameter("day");
		String aclass=request.getParameter("aclass");
			users user = new users();
            user.setId(id);
            user.setAClass(aclass);
            user.setWeek(week);
            user.setDay(day);
            */
		HttpServletRequest req = (HttpServletRequest) request;
		
		String userId = (String)req.getSession().getAttribute(loginservlet.SESSION_USER_ID);
            
            userDaoimpl ud = new userDaoimpl(); 
            users user = ud.onDutyTime(userId).get(0);
      //      if(ud.onDutyTime(id)){  
	        request.setAttribute("week", user.getWeek()); //��request���з�����Ϣ 
	        request.setAttribute("day", user.getDay());
	        request.setAttribute("aclass", user.getAClass());
	        System.out.println("������������һ��");
		// pass the request along the filter chain
		chain.doFilter(request, response);//��Ŀ����Դִ�У�����
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("----��������ʼ��----");
	}

}
